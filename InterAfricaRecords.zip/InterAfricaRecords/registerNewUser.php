<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Inter-Africa</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
<link href="css/layout.css" rel="stylesheet" type="text/css" />

</head>

<body class="container">
	
    <div class="container">
    	<div class="row">
        	<div class="col-sm-6 col-md-4 col-md-offset-4">
            	<div class="panel panel-default">
                <div id="header"></div>
                <div class="panel-heading">Login To Proceed</div>
                <div class="panel-body">
                  <form id="form1" name="form1" method="POST" action="<?php echo $loginFormAction; ?>">
                   
                   
									<div class="col-sm-12 col-md-10  col-md-offset-1 ">
										<div class="form-group">
											<div class="input-group">
											
													
												<input class="form-control" placeholder="Username" name="loginname" type="text" autofocus>
											</div>
										</div>
										<div class="form-group">
											<div class="input-group">
												
													
												<input class="form-control" placeholder="Password" name="password" type="password" value="">
											</div>
										
										<div class="form-group">
											<input type="submit" class="btn btn-lg btn-primary btn-block" value="Sign in">
										</div>
									</div>
								</div>
                   
                   </div>
                  </form>
                	<div class="panel-footer ">
						Inter Africa Internal Records System
					</div>
                </div>
                
                </div>
            </div>
        </div>
    </div>

</body>
</html>

