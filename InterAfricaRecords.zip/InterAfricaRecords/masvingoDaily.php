<?php require_once('Connections/connect.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO masvingo (RegNumber, DriverName, Route, Cash, Diesel, Expenses, Auditor , NetCash) VALUES (%s, %s, %s, %s, %s, %s, %s  , $netCash)",
                       GetSQLValueString($_POST['busReg'], "text"),
                       GetSQLValueString($_POST['driverName'], "text"),
                       GetSQLValueString($_POST['Route'], "text"),
                       GetSQLValueString($_POST['cash'], "int"),
                       GetSQLValueString($_POST['diesel'], "int"),
                       GetSQLValueString($_POST['expenses'], "int"),
                       GetSQLValueString($_POST['auditor2'], "text"));

  mysql_select_db($database_connect, $connect);
  $Result1 = mysql_query($insertSQL, $connect) or die(mysql_error());

  $insertGoTo = "masvingoDaily.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
	 $cash = $_POST['cash'];
 $diesel = $_POST['diesel'];
 $expense = $_POST['expenses'];
 $netCash = $cash - $diesel - $expense;
  $insertSQL = sprintf("INSERT INTO masvingo (RegNumber, DriverName, Route, Cash, Diesel, Expenses, NetCash,) VALUES (%s, %s, %s, %s, %s, %s, '{$netCash}')",
                       GetSQLValueString($_POST['busReg'], "text"),
                       GetSQLValueString($_POST['driverName'], "text"),
                       GetSQLValueString($_POST['Route'], "text"),
                       GetSQLValueString($_POST['cash'], "int"),
                       GetSQLValueString($_POST['diesel'], "int"),
                       GetSQLValueString($_POST['expenses'], "int"));

  mysql_select_db($database_connect, $connect);
  $Result1 = mysql_query($insertSQL, $connect) or die(mysql_error());
}

mysql_select_db($database_connect, $connect);
$query_Recordset1 = "SELECT * FROM masvingo";
$Recordset1 = mysql_query($query_Recordset1, $connect) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Inter-Africa</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
<link href="css/layout.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationSelect.css" rel="stylesheet" type="text/css" />
<script src="js/bootstrap.js"></script>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
<script src="SpryAssets/SpryValidationSelect.js" type="text/javascript"></script>
</head>

<body class="container">
	
    <div class="container">
    	<div class="row">
        	<div class="col-sm-6 col-md-4 col-md-offset-4">
            	<div class="panel panel-default">
                <div id="header"></div>
                <div class="panel-heading">Enter  Logsheet Values</div>
                <div class="panel-body">
                  <form action="<?php echo $editFormAction; ?>" id="form1" name="form1" method="POST">
                    <span id="sprytextfield1">
                    <label for="driverName"></label>
                    <input type="text" class="form-control" name="driverName" id="driverName" placeholder="enter your Driver Name"/>
                    <span class="textfieldRequiredMsg">A value is required.</span></span>
                    
                    
                    <span id="sprytextfield3">
                    <label for="busReg"></label>
                    <span id="sprytextfield4">
                    <input type="text" class="form-control" name="busReg" id="busReg" placeholder="enter Bus Reg Number"/>
                    <span class="textfieldRequiredMsg">A value is required.</span></span><span class="textfieldRequiredMsg">A value is required.</span></span>
                    <p id="textField" class="form-group">
                      Select Route
                      <label for="route"></label>
                      <select name="Route" class="dropDown" id="Route">
                        <option value="Masvingo Harare" <?php if (!(strcmp("Masvingo Harare", $row_Recordset1['Route']))) {echo "selected=\"selected\"";} ?>>Masvingo-Harare</option>
                        <option value="Masvingo-Chiredzi" <?php if (!(strcmp("Masvingo-Chiredzi", $row_Recordset1['Route']))) {echo "selected=\"selected\"";} ?>>Masvingo-Bulawayo</option>
                        <option value="Masvingo-Mutare" <?php if (!(strcmp("Masvingo-Mutare", $row_Recordset1['Route']))) {echo "selected=\"selected\"";} ?>>Masvingo-Mutare</option>
                        <?php
do {  
?>
                        <option value="<?php echo $row_Recordset1['Route']?>"<?php if (!(strcmp($row_Recordset1['Route'], $row_Recordset1['Route']))) {echo "selected=\"selected\"";} ?>><?php echo $row_Recordset1['Route']?></option>
                        <?php
} while ($row_Recordset1 = mysql_fetch_assoc($Recordset1));
  $rows = mysql_num_rows($Recordset1);
  if($rows > 0) {
      mysql_data_seek($Recordset1, 0);
	  $row_Recordset1 = mysql_fetch_assoc($Recordset1);
  }
?>
                      </select>
                        
                         <label for="cash"></label>
                      
                      <p><input type="number" class="form-control" name="cash" id="cash" placeholder="enter Bus Cash"/></p>
                      
                      <p><input type="number" class="form-control" name="diesel" id="diesel" placeholder="enter diesel amount"/></p>
                      
                      <input type="number" class="form-control" name="expenses" id= "expenses" placeholder="enter Total Expenses"/>
                    <p class="form-group">
                      
                      <label for="expenses"></label>
                      <label for="auditor"></label>
                      <span id="sprytextfield5">
                      <input type="text" class="form-control dropDown" name="auditor2" id="auditor2" placeholder="enter Auditor name" />
                      <span class="textfieldRequiredMsg">A value is required.</span></span>
                      <p>
                      <input type="submit" class="btn btn-lg btn-primary btn-block" name="login" id="login" value="enter records" />
                    </p>
                    <input type="hidden" name="MM_insert" value="form1" />
                  </form>
                	<div class="panel-footer ">Inter Africa Internal Records System </div>
                </div>
                
                </div>
            </div>
        </div>
    </div>

<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4");
var sprytextfield6 = new Spry.Widget.ValidationTextField("sprytextfield6");
var sprytextfield7 = new Spry.Widget.ValidationTextField("sprytextfield7");
var sprytextfield9 = new Spry.Widget.ValidationTextField("sprytextfield9", "integer");
var sprytextfield10 = new Spry.Widget.ValidationTextField("sprytextfield10", "integer");
var sprytextfield11 = new Spry.Widget.ValidationTextField("sprytextfield11", "integer");
var spryselect1 = new Spry.Widget.ValidationSelect("spryselect1");
var sprytextfield5 = new Spry.Widget.ValidationTextField("sprytextfield5");
</script>
</body>
</html>
<?php
mysql_free_result($Recordset1);
?>
