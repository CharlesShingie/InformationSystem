<?php require_once('Connections/connect.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "harareDieselForm")) {
  $updateSQL = sprintf("UPDATE harare_diesel SET Supplier=%s, Vehicle=%s, Trailer=%s, DeliverNote=%s, MeterReadingInitial=%s, MeterdingAfter=%s, AvailableDiesel=%s WHERE ReceivedBy=%s",
                       GetSQLValueString($_POST['supplier'], "text"),
                       GetSQLValueString($_POST['vehicle'], "text"),
                       GetSQLValueString($_POST['trailer'], "text"),
                       GetSQLValueString($_POST['deliverynote'], "int"),
                       GetSQLValueString($_POST['meterstart'], "int"),
                       GetSQLValueString($_POST['meterend'], "int"),
                       GetSQLValueString($_POST['AvailablehiddenField'], "int"),
                       GetSQLValueString($_POST['receiver'], "int"));

  mysql_select_db($database_connect, $connect);
  $Result1 = mysql_query($updateSQL, $connect) or die(mysql_error());
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "harareDieselForm")) {
  $insertSQL = sprintf("INSERT INTO harare_diesel (DieselReceived, Supplier, Vehicle, Trailer, DeliverNote, MeterReadingInitial, MeterdingAfter, ReceivedBy) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['diesel'], "int"),
                       GetSQLValueString($_POST['supplier'], "text"),
                       GetSQLValueString($_POST['vehicle'], "text"),
                       GetSQLValueString($_POST['trailer'], "text"),
                       GetSQLValueString($_POST['deliverynote'], "int"),
                       GetSQLValueString($_POST['meterstart'], "int"),
                       GetSQLValueString($_POST['meterend'], "int"),
                       GetSQLValueString($_POST['receiver'], "text"));

  mysql_select_db($database_connect, $connect);
  $Result1 = mysql_query($insertSQL, $connect) or die(mysql_error());
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "harareDieselForm")) {
  $received = $_POST['diesel'];
  $total = $row_HarareDiesel['AvailableDiesel'] ;
  $available = $received + $total;
  $insertSQL = sprintf("INSERT INTO harare_diesel (DieselReceived, Supplier, Vehicle, Trailer, DeliverNote, MeterReadingInitial, MeterdingAfter, ReceivedBy , AvailableDiesel) VALUES (%s, %s, %s, %s, %s, %s, %s, %s , $available)",
                       GetSQLValueString($_POST['diesel'], "int"),
                       GetSQLValueString($_POST['supplier'], "text"),
                       GetSQLValueString($_POST['vehicle'], "text"),
                       GetSQLValueString($_POST['trailer'], "text"),
                       GetSQLValueString($_POST['deliverynote'], "int"),
                       GetSQLValueString($_POST['meterstart'], "int"),
                       GetSQLValueString($_POST['meterend'], "int"),
                       GetSQLValueString($_POST['receiver'], "text"));

  mysql_select_db($database_connect, $connect);
  $Result1 = mysql_query($insertSQL, $connect) or die(mysql_error());
}

mysql_select_db($database_connect, $connect);
$query_HarareDiesel = "SELECT * FROM harare_diesel";
$HarareDiesel = mysql_query($query_HarareDiesel, $connect) or die(mysql_error());
$row_HarareDiesel = mysql_fetch_assoc($HarareDiesel);
$totalRows_HarareDiesel = mysql_num_rows($HarareDiesel);

mysql_select_db($database_connect, $connect);
$query_updateDiesel = "SELECT * FROM harare_diesel";
$updateDiesel = mysql_query($query_updateDiesel, $connect) or die(mysql_error());
$row_updateDiesel = mysql_fetch_assoc($updateDiesel);
$totalRows_updateDiesel = mysql_num_rows($updateDiesel);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Harare Diesel Record | Inter-Africa</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
<link href="css/layout.css" rel="stylesheet" type="text/css" />
<script src="js/bootstrap.js"></script>
</head>

<body class="container">

	 
     
    	<div class="row">
        	<div class="col-sm-6 col-md-4 col-md-offset-4">
            	<div class="panel panel-default">
                <div id="header"></div>
                <div class="panel-heading">Harare Received Diesel</div>
                <div class="panel-body">
                  <form action="<?php echo $editFormAction; ?>" method="POST"" name="harareDieselForm" id="harareDieselForm"form1>
                    
                    <label for="diesel"></label> 
                    <input type="text" class="form-control" name="diesel" id="diesel" placeholder="enter Number of Litres Received "/>
                   
                    
                      <label for="supplier"></label>
                      <input type="text" class="form-control" name="supplier" id="supplier" placeholder="enter Diesel Supplier name" />
                      
                      <label for="Vehicles"></label>
                      <input type="text" class="form-control" name="vehicle" id="vehicle" placeholder="enter Vehicle Registration Number" />
                      
                      <label for="trailer"></label>
                      <input type="text" class="form-control" name="trailer" id="trailer" placeholder="enter Trailer registration Number" />
                      
                      <label for="deliverynote"></label>
                      <input type="text" class="form-control" name="deliverynote" id="supplier" placeholder="enter Delivery note name" />
                      
                      <label for="meterStart"></label>
                      <input type="text" class="form-control" name="meterstart" id="meterStart" placeholder="enter starting Meter Reading" />
                      
                       <label for="meterEnd"></label>
                      <input type="text" class="form-control" name="meterend" id="meterEnd" placeholder="enter ending Meter Reading" />
                      
                       <label for="receiver"></label>
                      <input type="text" class="form-control" name="receiver" id="meterStart" placeholder="Received by (your name)" />
                      
                      
                    <br/>
                    <p>
                      <input type="submit" class="btn btn-lg btn-primary btn-block" name="recordDiesel" id="Record Diesel" value="Record Diesel" />
                    </p>
                    
                      
                    
                   <!-- <a href="#"/>
                    <input type="button" class="btn btn-lg btn-primary btn-block" name="dieselIn" id="dieselIn" value="Record Diesel Receipt" /> -->
                   <input type="hidden" name="MM_insert" value="harareDieselForm" />
                   </p>
                   <input name="AvailablehiddenField" type="hidden" id="AvailablehiddenField" value="<?php echo $row_HarareDiesel['AvailableDiesel']; ?>" />
                   <input type="hidden" name="MM_update" value="harareDieselForm" />
                  </form> 
                  </div>
                  </div>
                  </div>
    	
    </div>
    <div class="content">
    </div>
    <footer>
    copyright &copy; 2017 Inter-Africa Internal Records System designed by | Mr C Dziruni
    </footer>
</body>
</html>
<?php
mysql_free_result($HarareDiesel);

mysql_free_result($updateDiesel);
?>
