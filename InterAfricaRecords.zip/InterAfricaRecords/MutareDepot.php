<?php require_once('Connections/connect.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$currentPage = $_SERVER["PHP_SELF"];

$maxRows_mutare = 10;
$pageNum_mutare = 0;
if (isset($_GET['pageNum_mutare'])) {
  $pageNum_mutare = $_GET['pageNum_mutare'];
}
$startRow_mutare = $pageNum_mutare * $maxRows_mutare;

mysql_select_db($database_connect, $connect);
$query_mutare = "SELECT * FROM masvingo, mutare ORDER BY `Time` DESC";
$query_limit_mutare = sprintf("%s LIMIT %d, %d", $query_mutare, $startRow_mutare, $maxRows_mutare);
$mutare = mysql_query($query_limit_mutare, $connect) or die(mysql_error());
$row_mutare = mysql_fetch_assoc($mutare);

if (isset($_GET['totalRows_mutare'])) {
  $totalRows_mutare = $_GET['totalRows_mutare'];
} else {
  $all_mutare = mysql_query($query_mutare);
  $totalRows_mutare = mysql_num_rows($all_mutare);
}
$totalPages_mutare = ceil($totalRows_mutare/$maxRows_mutare = 10;
$pageNum_mutare = 0;
if (isset($_GET['pageNum_mutare'])) {
  $pageNum_mutare = $_GET['pageNum_mutare'];
}
$startRow_mutare = $pageNum_mutare * $maxRows_mutare;

mysql_select_db($database_connect, $connect);
$query_mutare = "SELECT * FROM masvingo, mutare ORDER BY `Time` DESC";
$query_limit_mutare = sprintf("%s LIMIT %d, %d", $query_mutare, $startRow_mutare, $maxRows_mutare);
$mutare = mysql_query($query_limit_mutare, $connect) or die(mysql_error());
$row_mutare = mysql_fetch_assoc($mutare);

if (isset($_GET['totalRows_mutare'])) {
  $totalRows_mutare = $_GET['totalRows_mutare'];
} else {
  $all_mutare = mysql_query($query_mutare);
  $totalRows_mutare = mysql_num_rows($all_mutare);
}
$totalPages_mutare = ceil($totalRows_mutare/$maxRows_mutare)-1;

$queryString_mutare = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_mutare") == false && 
        stristr($param, "totalRows_mutare") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_mutare = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_mutare = sprintf("&totalRows_mutare=%d%s", $totalRows_mutare, $queryString_mutare);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Masvingo Depot | Inter-Africa</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
<link href="css/layout.css" rel="stylesheet" type="text/css" />
<script src="js/bootstrap.js"></script>
</head>

<body class="container">
	<div id="header">
	  <p>&nbsp;</p>
	  <p>&nbsp;</p>
    	
    </div>
     <div class="contentLeft col-md-2">
    	<h3>Admin Actions</h3>
        <p><a href="DeleteUsers.php"Delete Users>Delete User</a></p>
        <p><a href="NewUser.php"> Register New User </a></p>
        <p><a href="#">Edit User Accounts</a></p>
        <p><a href="adminPage.php">Admin Home Page</a></p>
    </div>
    <div class="col-sm-9">
   	  <table class="table table-hover" id="task-table">
      <h3>Masvingo Depot phone: Mr XXX 0776786971</h3> Showing <?php echo ($startRow_mutare + 1) ?> to <?php echo min($startRow_mutare + $maxRows_mutare, $totalRows_mutare) ?> of <?php echo $totalRows_mutare ?> Bus  Records  Today
<thead>
   	  <th> Time</th>
    	<th>Bus</th>
        <th>Route</th>
        <th>Driver</th>
        <th>Cash</th>
        <th>Fuel</th>
        <th>Expenses</th>
        <th>Net Cash</th>
        <th  >Auditor(s)</th>
    </thead>
    
    <tbody>
      <?php if ($totalRows_mutare &gt; 0) { // Show if recordset not empty ?>
      <tr>
        <td><?php echo $row_mutare['Time']; ?></td>
        <td><?php echo $row_mutare['RegNumber']; ?></td>
        <td><?php echo $row_mutare['Route']; ?></td>
        <td><?php echo $row_mutare['DriverName']; ?></td>
        <td><?php echo $row_mutare['Cash']; ?></td>
        <td><?php echo $row_mutare['Diesel']; ?></td>
        <td><?php echo $row_mutare['Expenses']; ?></td>
        <td bgcolor="#6666FF"><?php echo $row_mutare['NetCash']; ?></td>
        <td><?php echo $row_mutare['Auditor']; ?></td>
      </tr>
      <?php } // Show if recordset not empty ?>
<tr>
        <td><a href="<?php printf("%s?pageNum_mutare=%d%s", $currentPage, max(0, $pageNum_mutare - 1), $queryString_mutare); ?>">Previous</a></td>
        <td><a href="<?php printf("%s?pageNum_mutare=%d%s", $currentPage, min($totalPages_mutare, $pageNum_mutare + 1), $queryString_mutare); ?>">Next</a></td>
        
        <td><a class = "btn btn-success btn-print" href = "" onclick = "window.print()"><i class ="glyphicon glyphicon-print"></i> Print</a></td>
        </tr>
    </tbody>
    </table>
    </div>
    
<footer>
    copyright &copy; 2017 Inter-Africa Internal Records System designed by | Mr C Dziruni
    </footer>
</body>
</html>
<?php
mysql_free_result($mutare);
?>
