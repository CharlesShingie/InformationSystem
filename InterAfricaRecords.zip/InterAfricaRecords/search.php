<?php require_once('Connections/connect.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
if (isset($_POST['search'])) {
	$searchq = $_POST['search'];
	$searchq = preg_replace("#[^0-9a-z]#i","",$searchq);
	
	$query = mysql_query("SELECT * FROM adminusers WHERE name LIKE '%$searchq%' OR username LIKE '%searchq%' ") or die("could not search!");
	$count = mysql_num_rows($query);
	if ($count ==0){
		$output = 'there was no serch result!';}
		else {
			while ($row = mysql_fetch_array($query)){
				$fname =  $row['name'];
				$uname =  $row['username'];
				$lname =  $row['surname'];
				$id =  $row['userID'];
				$output .= '<div> '.fname.' '.lname.' '; 
			}
		}
	}
	
	
	



mysql_select_db($database_connect, $connect);
$query_serarch = "SELECT * FROM adminusers";
$serarch = mysql_query($query_serarch, $connect) or die(mysql_error());
$row_serarch = mysql_fetch_assoc($serarch);
$totalRows_serarch = mysql_num_rows($serarch);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Inter-Africa</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
<link href="css/layout.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<script src="js/bootstrap.js"></script>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
</head>
		<body>
					<form action ="" method="POST">
						<input type="text" name="search" placeholder="Search for ..">
						<input type="submit" name="searchButton" value="search">
					</form>
					<?php print("$output"); ?>
		</body>
</html>
<?php
mysql_free_result($serarch);
?>
