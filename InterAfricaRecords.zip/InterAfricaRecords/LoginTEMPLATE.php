<!DOCTYPE html>
<html>
<head>
<style>
table {
    width: 100%;
    border-collapse: collapse;
}

table, td, th {
    border: 1px solid black;
    padding: 5px;
}

th {text-align: left;}
</style>
</head>
<body>

<p>
  <?php


$con = mysqli_connect('localhost','root','','inter-africa');
if (!$con) {
    die('Could not connect: ' . mysqli_error($con));
}

/*mysqli_select_db($con,"ajax_demo");
$sql="SELECT * FROM adminusers";
$result = mysqli_query($con,$sql);

//echo "<table>
<tr>
<th>UserID</th>
<th>name</th>
<th>Lastname</th>
<th>Username</th>
<th>Password</th>
<th>Depot<th>
</tr>";
while($row = mysqli_fetch_array($result)) {
    echo "<tr>";
    echo "<td>" . $row['userID'] . "</td>";
    echo "<td>" . $row['name'] . "</td>";
    echo "<td>" . $row['surname'] . "</td>";
    echo "<td>" . $row['username'] . "</td>";
    echo "<td>" . $row['password'] . "</td>";
	echo "<td>" . $row['depot'] . "</td>";
    echo "</tr>";
}
echo "</table>"; */
 $query2 = "SELECT * FROM harare_diesel";
 mysqli_select_db($con,"ajax_demo");
$row = mysqli_fetch_array($query2);
$row['AvailableDiesel'];

$diesel = mysqli_query($con,form1);
 
 $query = "INSERT into harare_diesel (AvailableDiesel)VALUES ('$available')";
 $today = $_POST['diesel'];
 $current = $row['AvailableDiesel'];
 $available = $today + $current;
mysqli_close($con);
?>
</p>
<form action="" method="post" name="form1" target="_self">
  <label for="diesel">diesel</label>
  <input type="text" name="diesel" id="diesel">
diesel addition
<input type="submit" name="add Diesel" id="add Diesel" value="Submit">
</form>
</body>
</html>