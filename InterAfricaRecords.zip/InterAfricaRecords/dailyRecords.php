<?php require_once('Connections/connect.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
	$cash = $_POST['cash'];
	$diesel = $_POST['diesel'];
	$expenses = $_POST['expenses'];
	$netCash = $cash - $diesel- $expenses;

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO harare (RegNumber, DriverName, Route, Cash, Diesel, Expenses, auditor, NetCash) VALUES (%s, %s, %s, %s, %s, %s, %s , $netCash)",
  
                       GetSQLValueString($_POST['busReg'], "text"),
                       GetSQLValueString($_POST['driverName'], "text"),
                       GetSQLValueString($_POST['route'], "text"),
                       GetSQLValueString($_POST['cash'], "int"),
                       GetSQLValueString($_POST['diesel'], "int"),
                       GetSQLValueString($_POST['expenses'], "int"),
                       GetSQLValueString($_POST['auditor'], "text"));

  mysql_select_db($database_connect, $connect);
  $Result1 = mysql_query($insertSQL, $connect) or die(mysql_error());

  $insertGoTo = "dailyRecords.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_connect, $connect);
$query_dailyRecords = "SELECT * FROM harare";
$dailyRecords = mysql_query($query_dailyRecords, $connect) or die(mysql_error());
$row_dailyRecords = mysql_fetch_assoc($dailyRecords);
$totalRows_dailyRecords = mysql_num_rows($dailyRecords);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Inter-Africa</title>
<link href="css/bootstrap.css" rel="stylesheet" type="text/css" />
<link href="css/layout.css" rel="stylesheet" type="text/css" />
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css" />
<script src="js/bootstrap.js"></script>
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
</head>

<body class="container">
	
    <div class="container">
    	<div class="row">
        	<div class="col-sm-6 col-md-4 col-md-offset-4">
            	<div class="panel panel-default">
                <div id="header"></div>
                <div class="panel-heading">Login To Proceed</div>
                <div class="panel-body">
                  <form action="<?php echo $editFormAction; ?>" id="form1" name="form1" method="POST">
                    <span id="sprytextfield1">
                    <label for="driverName"></label>
                    <input type="text" class="form-control" name="driverName" id="driverName" placeholder="enter your Driver Name"/>
                    <span class="textfieldRequiredMsg">A value is required.</span></span>
                    
                    
                    <span id="sprytextfield3">
                    <label for="busReg"></label>
                    <input type="text" class="form-control" name="busReg" id="busReg" placeholder="enter Bus Reg Number"/>
                    <span class="textfieldRequiredMsg">A value is required.</span></span>
                    <p id="textField">
                    
                    <span id="sprytextfield4">
                    <label for="route"></label>
                    <input type="text" class="form-control" name="route" id="route" placeholder="enter route"/>
                    <span class="textfieldRequiredMsg">A value is required.</span></span>
                    
                    <span id="sprytextfield8">
                    <label for="cash"></label>
                    <input type="text" class="form-control" name="cash" id="route" placeholder="enter cash"/>
                    <span class="textfieldRequiredMsg">A value is required.</span></span>
                    
                    <span id="sprytextfield5">
                    <label for="diesel"></label>
                    <input type="text" class="form-control" name="diesel" id="diesel" placeholder="enter diesel used"/>
                    <span class="textfieldRequiredMsg">A value is required.</span></span>
                    
                     <span id="sprytextfield5">
                    <label for="expenses"></label>
                    <input type="text" class="form-control" name="expenses" id="expenses" placeholder="enter total expenses "/>
                    <span class="textfieldRequiredMsg">A value is required.</span></span>
                    
                     <span id="sprytextfield1">
                    <label for="auditor"></label>
                    <input type="text" class="form-control" name="auditor" id="auditor" placeholder="auditor name"/>
                    <span class="textfieldRequiredMsg">A value is required.</span></span>
                     
                    
                    
                    
                    <p>
                      <input type="submit" class="btn btn-lg btn-primary btn-block" name="login" id="login" value="enter records" />
                    </p>
                    <input type="hidden" name="MM_insert" value="form1" />
                  </form>
                	<div class="panel-footer ">
						click here to Login as a super Adminstrator
					</div>
                </div>
                
                </div>
            </div>
        </div>
    </div>

<script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
</script>
</body>
</html>
<?php
mysql_free_result($dailyRecords);
?>
